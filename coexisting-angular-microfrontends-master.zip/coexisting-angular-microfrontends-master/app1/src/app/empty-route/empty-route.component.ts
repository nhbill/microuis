import { Component } from '@angular/core';

@Component({
  selector: 'app1-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
