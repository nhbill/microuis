import { Component } from '@angular/core';

@Component({
  selector: 'app2-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
